TERMS: ENERGY, NUMBER, SPACE, TIME
Pam Eisect = SPACE + TIME
Percy Geanes = ENERGY + SPACE
Reuben Camps = NUMBER + SPACE
Regine Tyme = ENERGY + TIME
Ruben Timme = NUMBER + TIME
Remy Bergunen = ENERGY + NUMBER
