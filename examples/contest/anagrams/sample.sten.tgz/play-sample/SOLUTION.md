TERMS: ENERGY, NUMBER, SPACE, TIME
Pete Micas = SPACE + TIME
Spence Geary = ENERGY + SPACE
Reuben Camps = NUMBER + SPACE
Meg Tierney = ENERGY + TIME
Ben Mutimer = NUMBER + TIME
Emy Runenberg = ENERGY + NUMBER
